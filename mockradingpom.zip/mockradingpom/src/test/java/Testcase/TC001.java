package Testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import mocktradingbase.MockTradingCore;
import pages.Mocktrading_LoginPage;
import utility.Reporting;

public class TC001 extends MockTradingCore {
	
	@BeforeTest
	public void testid()
	{
		testcase="TC001";
		Reporting.StartTestcase();
	}
	
	
	@Test
	public void run() throws Exception {
		
		new Mocktrading_LoginPage()
		.Mocktrading_Username("pp")
		.Mocktrading_Password("pp")
		.Mocktrading_SubmitBtn();
		
	}

}
