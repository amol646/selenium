package pages;

import java.io.IOException;

import mocktradingbase.MockTradingCore;

public class MainMenuPage extends MockTradingCore

{
	public void MainMenuPage() 
	{
		try {
			IsDisplayedByXpath("//*[@id=\'content\']/table[1]/tbody/tr/td/table/tbody/tr[1]/td[1]/b/font");
			System.out.println("MainMenuPage verified sucessfully");
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in verfiying the page "+e.getMessage());
		}
		
	}
	
	public void MainMenuPg_EnterintoContract () throws IOException
	{
		ClickByName(null);
	}
	
	public void MainMenuPg_ExitContract () throws IOException
	{
		ClickByName(null);
	}
	
	public void MainMenuPg_CancelanOrder () throws IOException
	{
		ClickByName(null);
	}
	
	
	
	
}
