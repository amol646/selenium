package pages;

import java.io.IOException;

import mocktradingbase.MockTrading;

public class SelectCommoditypage extends MockTrading

{
	public void selectcommodityhomepage() throws IOException
	{
		IsDisplayedByXpath("");
	}
	
	public void SelectCommodityPg_SelectCommodity() throws IOException
	{
		SelectByName(null, null);
	}

	
	
}
