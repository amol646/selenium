package utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import mocktradingbase.MockTrading;
import mocktradingbase.MockTradingCore;

public class Reporting extends MockTradingCore {

	static ExtentReports extent;
	static ExtentTest logger;
	

	public static void StartReport()
	
	{

		String mytimeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		
		String extrprtpath = "E:\\amol\\Amol_Selenium\\Cucumber\\Report\\" + "TestExecutionReport" +"_" + mytimeStamp +".html" ;
		extent = new ExtentReports (extrprtpath, true);

	}

	public static void executereport(String name1,String status) throws IOException

	{
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

		TakesScreenshot takescrn= (TakesScreenshot) driver;

		File SrcFile=takescrn.getScreenshotAs(OutputType.FILE);
		File DestFile=new File("E:\\amol\\Amol_Selenium\\Cucumber\\Screenshot\\"+ name1  +"_"+ timeStamp +".jpg");
		Files.copy(SrcFile, DestFile);


		if(status.toUpperCase().equals("PASS")){
			logger.log(LogStatus.PASS, name1 +logger.addScreenCapture("E:\\amol\\Amol_Selenium\\Cucumber\\Screenshot\\"+ name1  +"_"+ timeStamp +".jpg"));

			
		}
		if(status.toUpperCase().equals("FAIL")){
			logger.log(LogStatus.FAIL, name1 +logger.addScreenCapture("E:\\amol\\Amol_Selenium\\Cucumber\\Screenshot\\"+ name1  +"_"+ timeStamp +".jpg"));
		}
		else if(status.toUpperCase().equals("INFO")){
			logger.log(LogStatus.INFO, name1 +logger.addScreenCapture("E:\\amol\\Amol_Selenium\\Cucumber\\Screenshot\\"+ name1  +"_"+ timeStamp +".jpg"));
		}
	}

	public static void FlushReport(){
		extent.endTest(logger);
		extent.flush();
		
	}
	public static void StartTestcase(String data){

		
		logger = extent.startTest(data); 
		
	}


}
