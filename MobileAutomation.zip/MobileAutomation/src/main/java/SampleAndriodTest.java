import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class SampleAndriodTest {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		// TODO Auto-generated method stub
		/*
		 * We will set the mobile capabilities 	
		 * We launch the mobile driver
		 * We will launch a sample mobile app
		 * We will perform basic test
		 * And close the driver
		 */

		AndroidDriver<AndroidElement> mobileDriver;

		try {

			String appiumURl = "http:127.0.0.1:4723/wd/hub";
			String appPath = System.getProperty("user.dir")+"\\app\\AccWeather.apk";

			DesiredCapabilities androidCap = new DesiredCapabilities();
			androidCap.setCapability(MobileCapabilityType.DEVICE_NAME, "4d007e0a87be40cf");
			androidCap.setCapability(MobileCapabilityType.APP, appPath);
			androidCap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			androidCap.setCapability(MobileCapabilityType.PLATFORM_VERSION, "5.0.1");

			mobileDriver = new AndroidDriver<>(new URL(appiumURl),androidCap);	//launch the driver & app
			/*
				Action
			 */

			Thread.sleep(5000);
			String xpath = "//android.widget.Button[@text='I Agree']";
			mobileDriver.findElement(By.xpath(xpath)).click();
			Thread.sleep(5000);
			mobileDriver.quit();

		}catch(Exception e) {
			System.out.println(e.getMessage());
		}


	}

}


