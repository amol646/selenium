package scripting;

import java.io.IOException;

import org.testng.annotations.Test;

public class TC003_Cancelorder extends MockTradingCore
{
	@Test(dataProvider = "Authentication")
	public void cancelorder(String url,String us1,String pw1,String comm,String dur,String ordertype) throws IOException
	{
		System.out.println("TC003_Cancelorder");
		launchbrowserwithurl(url);
		
		EnterByName("UserIDCheck",us1);				

		EnterByName("UserPWDCheck",pw1);

		ClickByXpath("//input[@class='button' and @type='submit']") ;

		IsDisplayedByXpath("//font[@size='4'and contains(text(),'Main Menu')]");
		
		//ClickByName("Cancel an Order");
		
		//ClickByXpath("//input[@class='button' and @value='   Cancel Order   ']");
		
		//IsDisplayedByXpath("//font[@size='4'and contains(text(),'Main Menu')]");
		
		//ClickByXpath("//a[@class='menu' and contains(text(),'logout')]");
		
		
	}
}
