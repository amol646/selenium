package scripting;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utility.Reporting;


public class TC001_AddContract extends MockTradingCore {
	
	@BeforeMethod
	public void beforerun()
	{
		testcase="TC001_AddContract"+"_iteration_"+i;
		Reporting.StartTestcase();
	}
	
	@Test(dataProvider = "Authentication")
	public static void addcontract(String url,String us1,String pw1,String comm,String dur,String ordertype) throws Throwable
	
	{ 		
		
		System.out.println("TC001_AddContract");
		System.out.println(url);
		System.out.println(us1);
		launchbrowserwithurl(url);		

		EnterByName(or.getProperty("Username"),us1);			

		EnterByName(or.getProperty("Password"),pw1);		

		ClickByXpath(or.getProperty("SubmitBtn")) ;	

		IsDisplayedByXpath(or.getProperty("Home_MainmenuPg"));

		//capturescreenshoot ("verification");

		//ClickByName("Enter a Contact");		

		//SelectByName("commodity",prp.getProperty("mocktrading_createcontact.commoditydropdwn.xpath")) ;		

		//ClickByXpath("//input[@class='button' and @type='submit']") ;	

		//ClickByXpath("(//input[@class='button' and @value='   Select This One   '])[1]");

		//ClickByXpath("//input[@class='button' and @type='submit']");

		//SelectByName("longshort", prp.getProperty("mocktrading_createcontact.durationdropdwn.xpath"));		

		//ClickByXpath("//input[@class='button' and @type='submit']");

		//SelectByName("ordertype", prp.getProperty("mocktrading_createcontact.ordertypdropdwn.xpath"));		

		//ClickByXpath("//input[@class='button' and @type='submit']");		

		//ClickByXpath("//input[@class='button' and @value='   Confirm   ']");		

		//IsDisplayedByXpath("//h2[contains(text(),'Order Added')]");			

		ClickByXpath(or.getProperty("Logout"));	
		
		i=i+1;
	
	
	}

}
