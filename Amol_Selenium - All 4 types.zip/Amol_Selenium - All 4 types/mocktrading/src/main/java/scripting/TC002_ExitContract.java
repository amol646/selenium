package scripting;

import java.io.IOException;

import org.testng.annotations.Test;

public class TC002_ExitContract extends MockTradingCore 

{
	@Test(dataProvider = "Authentication")
	public void editcontract(String url,String us1,String pw1,String comm,String dur,String ordertype) throws IOException
	{
		System.out.println("TC002_ExitContract");
	
	launchbrowserwithurl(url);
	
	EnterByName("UserIDCheck",us1);				

	EnterByName("UserPWDCheck",pw1);

	ClickByXpath("//input[@class='button' and @type='submit']") ;

	IsDisplayedByXpath("//font[@size='4'and contains(text(),'Main Menu')]");
	
	//ClickByName("Exit a Contact");
	
	//ClickByXpath("//input[@class='button' and @value='   Exit Position   ']");
	
	//SelectByName("ordertype", prp.getProperty("mocktrading_exitcontract.ordertypdropdwn.xpath"));		

	//ClickByXpath("//input[@class='button' and @type='submit']");
	
	//ClickByXpath("//input[@class='button' and @value='   Confirm   ']");
	
	//IsDisplayedByXpath("//h2[contains(text(),'Order Added')]");

	//ClickByXpath("//a[@class='menu' and contains(text(),'logout')]");

	
	}
}
