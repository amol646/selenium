package javapractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.*;
	/*
public class DriverProgram extends AddFunctions{
	String a;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//WebDriver seleniumwebdriver = new ChromeDriver();
		
		int i = 10;
		float f = 1.5f;
		double d = 1.5;
		char c = 'x';
		String s = "sqs";
		

		AddFunctions dp  = new AddFunctions();
		
		//System.out.println("My Name is " + dp.fullName);
		//dp.add("Amol", "Patil");
		//System.out.println("My Name is " + dp.fullName);
		
		System.out.println(dp.add(5, 10)+100);
		
		
		AddFunctions dp2  = new AddFunctions("defaultName");
		//dp2.add("Joe", "Daniel");
		
		System.out.println("My Name is " + dp.fullName);
		System.out.println("My Name is " + dp2.fullName);
			
		DriverProgram dri = new DriverProgram();
		dri.a = "Driver";
		
	
		
	}
	
	public void finalize(){
		System.out.println(a + " Object is destroyed");
	}
*/
	

	public class DriverProgram {

	   public static void main(String args[]) throws IOException {  
	      FileInputStream in = null;
	      FileOutputStream out = null;

	      try {
	         in = new FileInputStream("E:\\Amol_Selenium\\input.txt");
	         out = new FileOutputStream("E:\\Amol_Selenium\\output.txt");
	         
	         int c;
	         while ((c = in.read()) != -1) {
	            out.write(c);
	            System.out.print(Character.toChars(c));
	         }
	      }finally {
	         if (in != null) {
	            in.close();
	         }
	         if (out != null) {
	            out.close();
	         }
	      }
	   }
	}

	/*
}
*/