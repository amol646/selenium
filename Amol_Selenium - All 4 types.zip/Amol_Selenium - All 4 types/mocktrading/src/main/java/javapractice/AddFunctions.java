package javapractice;

public class AddFunctions{
	
	
	public String fullName;
	
	public AddFunctions () {
		fullName = "Noname";
	}
	
	public AddFunctions (String name) {
		fullName = name;
	}
	
	public void finalize(){
		System.out.println(fullName + " Object is destroyed");
	}
	
	public void add(String firstName, String lastName) {
		//String fullName;
		this.fullName = firstName + " " + lastName;
		
		//return fullName;
	}
	
	public int add(int a, int b) {
		int c;
		
		c = a + b;
		
		return c;
	}
}
