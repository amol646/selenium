package mocktradingbase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import utility.Reporting;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
//import java.io.*;
import java.util.concurrent.TimeUnit;

public class MockTrading  
{

	public static WebDriver driver;
	public static Properties prp;
	public static Properties or;


	public static void main(String[] args) throws IOException 
	{
		/*

		String[][] a=excelmethod();
		// TODO Auto-generated method stub

		//driver.findElement(By.name("UserIDCheck")).sendKeys("pp");
		EnterByName("UserIDCheck",a[1][0]);		

		//driver.findElement(By.name("UserPWDCheck")).sendKeys("pp");
		EnterByName("UserPWDCheck",a[1][1]);

		//driver.findElement(By.xpath("//input[@class='button' and @type='submit']")).click();		
		ClickByXpath("//input[@class='button' and @type='submit']") ;

		//driver.findElement(By.xpath("//font[@size='4'and contains(text(),'Main Menu')]")).isDisplayed() ;
		IsDisplayedByXpath("//font[@size='4'and contains(text(),'Main Menu')]");

		//driver.findElement(By.name("Enter a Contact")).click();
		ClickByName("Enter a Contact");

		//Select sel=new Select(driver.findElement(By.name("commodity")));
		//sel.selectByVisibleText("British Pound (B6)");

		SelectByName("commodity", "British Pound (B6)") ;

		//driver.findElement(By.xpath("//input[@class='button' and @type='submit']")).click();
		ClickByXpath("//input[@class='button' and @type='submit']") ;

		//driver.findElement(By.xpath("(//input[@class='button' and @value='   Select This One   '])[1]")).click();
		//driver.findElement(By.xpath("//input[@class='button' and @type='submit']")).click();

		ClickByXpath("(//input[@class='button' and @value='   Select This One   '])[1]");
		ClickByXpath("//input[@class='button' and @type='submit']");

		SelectByName("longshort", "Buy (Go Long)") ;

		//driver.findElement(By.xpath("//input[@class='button' and @type='submit']")).click();
		ClickByXpath("//input[@class='button' and @type='submit']");

		SelectByName("ordertype", "Market Order") ;

		//driver.findElement(By.xpath("//input[@class='button' and @type='submit']")).click();
		ClickByXpath("//input[@class='button' and @type='submit']");

		//driver.findElement(By.xpath("//input[@class='button' and @value='   Confirm   ']")).click();
		ClickByXpath("//input[@class='button' and @value='   Confirm   ']");

		//driver.findElement(By.xpath("//h2[contains(text(),'Order Added')]")).isDisplayed();
		IsDisplayedByXpath("//h2[contains(text(),'Order Added')]");


		//driver.findElement(By.xpath("//a[@class='menu' and contains(text(),'logout')]")).click();
		//ClickByXpath("//a[@class='menu' and contains(text(),'logout')]");
*/

	}

	public static void launchbrowserwithurl(String url) throws IOException 
{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "E:\\amol\\Amol_Selenium\\chromedriver.exe");
		driver = new ChromeDriver() ;	
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
		//capturescreenshoot ("launchbrowserwithurl");
		
		Reporting.executereport("launchbrowserwithurl", "INFO");
} 

	public static void ClickByXpath (String iXpathVal) throws IOException
	{
		try 
		{
			driver.findElement(By.xpath(iXpathVal)).click();
			//capturescreenshoot ("ClickByXpath");
			Reporting.executereport("ClickByXpath", "PASS");
			
		}
		catch(Exception e)
		{
			System.out.println("Not able to Perform Click Action for :" + iXpathVal + "--" + e.getMessage());
			//capturescreenshoot ("ClickByXpath");
			Reporting.executereport("ClickByXpath", "FAIL");
		}
	}

	public static void ClickByName(String iNameVal) throws IOException

	{
		try
		{
			driver.findElement(By.name(iNameVal)).click();
			Reporting.executereport("ClickByName", "PASS");
		}
		catch (Exception e)
		{
			System.out.println("Not able to Perform Click operation for :" + iNameVal + e.getMessage() );
			Reporting.executereport("ClickByName", "FAIL");
		}
	}

	public static void EnterByName(String iLocatorName,String iNameVal ) throws IOException
	{
		try
		{
			driver.findElement(By.name(iLocatorName)).clear();
			driver.findElement(By.name(iLocatorName)).sendKeys(iNameVal);
			//capturescreenshoot ("EnterByName","test");
			Reporting.executereport("EnterByName", "PASS");
		}
		catch (Exception e)
		{
			System.out.println("Not able to Perform Enter operation for :" + iLocatorName + e.getMessage() );
			//capturescreenshoot ("EnterByName","test");
			Reporting.executereport("EnterByName", "FAIL");
		}
	}

	public static boolean IsDisplayedByXpath(String iXpathVal) throws IOException
	{	boolean ires=false;
		try
		{
			driver.findElement(By.xpath(iXpathVal)).isDisplayed() ;
			//capturescreenshoot ("IsDisplayedByXpath");
			Reporting.executereport("IsDisplayedByXpath", "PASS");
			return ires=true;
		}
		catch(Exception e) 
		{
			System.out.println( "Not able to perform Validation using IsDisplayed for :"+ iXpathVal + e.getMessage());
			//capturescreenshoot ("IsDisplayedByXpath");
			Reporting.executereport("IsDisplayedByXpath", "FAIL");
		}
		return ires;

	}

	public static void  SelectByName (String ByLocatorvalue, String Valuetobeselectedinweblist) throws IOException 
	{
		try
		{
			Select sel=new Select(driver.findElement(By.name(ByLocatorvalue)));
			sel.selectByVisibleText(Valuetobeselectedinweblist);
			//capturescreenshoot ("SelectByName");
			Reporting.executereport("SelectByName", "PASS");
		}
		catch (Exception e)
		{
			System.out.println("Not able to perform Select Operation for :" + ByLocatorvalue + e.getMessage() );
			//capturescreenshoot ("SelectByName");
			Reporting.executereport("SelectByName", "FAIL");
			
		}

	}

	// Method to Learn how to use findbyelements

	public static void findbyelements(int a) 

	{
		List commoditieslist=driver.findElements(By.xpath("//td[@id='content']/table[2]/tbody/tr")) ;
		int a1=(commoditieslist.size())/3;
		System.out.println(a1);
		for (int i = 3; i <=commoditieslist.size();i++) 
		{
			if(i%3==0)
			{
				System.out.println(driver.findElement(By.xpath("//td[@id='content']/table[2]/tbody/tr["+i+"]/td/input")).getAttribute("value"));

				if(i==a)
				{
					driver.findElement(By.xpath("//td[@id='content']/table[2]/tbody/tr["+i+"]/td/input")).click();
				}
			}
		}
	}
	
	/*
	@DataProvider(name = "Authentication")
	//@Test
	public static String[][] excelmethod () throws IOException
	{
		String[][] arrdata=null;
		File testdata=new File("E:\\amol\\Amol_Selenium\\Test Data.xlsx");

		FileInputStream file=new FileInputStream(testdata);

		XSSFWorkbook wb=new XSSFWorkbook(file);
		XSSFSheet sheet=wb.getSheetAt(0);
		int rwcnt=sheet.getLastRowNum();
		int clscnt=sheet.getRow(0).getLastCellNum();
		
		System.out.println(rwcnt);
		System.out.println(clscnt);
		
		arrdata=new String[rwcnt][clscnt];	

		for (int i=1 ; i<=rwcnt; i++) 
		{
			XSSFRow row=sheet.getRow(i);
			for (int j = 0; j <clscnt; j++)
			{
				
				arrdata[i-1][j]=row.getCell(j).getStringCellValue();
			}


		}
		
		return arrdata;		
		
	}
	*/
	public static void mocktradeprpfile() throws IOException
	{
		FileInputStream file=new FileInputStream(new File("E:\\amol\\Amol_Selenium\\mocktrading\\locatorobjects.properties"));
		prp=new Properties();		
		prp.load(file);
		
	}
	
	public static void objectrepositoryfile() throws IOException  
	{
		FileInputStream file=new FileInputStream(new File("E:\\amol\\Amol_Selenium\\mockradingpom\\objectrepository.properties"));
		or = new Properties();
		or.load(file);
	}

	
	/*public static void capturescreenshoot (String name1) throws IOException
	{
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		
		TakesScreenshot takescrn= (TakesScreenshot) driver;
		
		File SrcFile=takescrn.getScreenshotAs(OutputType.FILE);
		File DestFile=new File("E:\\amol\\Amol_Selenium\\Screenshot\\"+ name1  +"_"+ timeStamp +".jpg");
		Files.copy(SrcFile, DestFile);
			
		
	}*/



} //End of Class Mocktrading 
