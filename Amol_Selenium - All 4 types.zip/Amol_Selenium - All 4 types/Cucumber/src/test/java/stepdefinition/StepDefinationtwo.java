package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import mocktradingbase.MockTradingCore;

public class StepDefinationtwo extends MockTradingCore {


	@Given("^navigate to the mocktrading url for login (\\d+)$")
	public void navigate_to_the_mocktrading_url_for_login(int arg1) throws Throwable {
		launchbrowserwithurl("http://www.mocktrading.com/");
	}

	@When("^I enter valid \"([^\"]*)\" and \"([^\"]*)\" for login (\\d+)$")
	public void I_enter_valid_and_for_login(String arg1, String arg2, int arg3) throws Throwable {
		EnterByName(or.getProperty("Username"), arg1);
		EnterByName(or.getProperty("Password"), arg2);
		ClickByXpath(or.getProperty("SubmitBtn"));
	}
	@Then("^I should see the mocktrading homepage for login (\\d+)$")
	public void I_should_see_the_mocktrading_homepage_for_login(int arg1) throws Throwable {
		IsDisplayedByXpath(or.getProperty("Home_MainmenuPg"));
	}


}
