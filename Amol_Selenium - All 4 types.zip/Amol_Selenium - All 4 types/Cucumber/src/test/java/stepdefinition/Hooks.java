package stepdefinition;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import gherkin.formatter.model.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import mocktradingbase.MockTradingCore;
import utility.Reporting;

public class Hooks extends MockTradingCore {




	@Before("@functional")
	public void beforehook2() throws IOException
	{	
		mocktradeprpfile();
		objectrepositoryfile();
		Reporting.StartReport();		


	}

	@Before
	public void beforehook(cucumber.api.Scenario iScenario) throws IOException
	{				
		//testcase="cucmber";
		Reporting.StartTestcase(iScenario.getName());
	}

	@After
	public void afterhook()
	{

		driver.close();
	}


	@After("@functional2")
	public void afterhoo2()
	{

		Reporting.FlushReport();

	}




}
