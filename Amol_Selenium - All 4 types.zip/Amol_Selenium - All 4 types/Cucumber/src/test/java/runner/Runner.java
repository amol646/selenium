package runner;

import java.io.IOException;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.testng.annotations.BeforeClass;

import cucumber.api.CucumberOptions;
import cucumber.api.java.Before;
import cucumber.api.junit.Cucumber;
//mocktrading1.feature
import cucumber.api.testng.AbstractTestNGCucumberTests;
import mocktradingbase.MockTradingCore;
import utility.Reporting;



@RunWith(Cucumber.class)
@CucumberOptions(
		features="E:\\amol\\Amol_Selenium\\Cucumber\\src\\test\\resources\\mocktradingfeature",
		glue= {"stepdefinition"},
		monochrome=true
		
		)
	
// Extends AbstractTestNGCucumberTests

public class Runner  {

	

}
