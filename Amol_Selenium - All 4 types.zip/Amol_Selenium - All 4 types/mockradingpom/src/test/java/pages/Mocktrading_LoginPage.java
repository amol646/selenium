package pages;

import java.io.IOException;

import mocktradingbase.MockTradingCore;

public class Mocktrading_LoginPage extends MockTradingCore {

	public Mocktrading_LoginPage() throws Exception
	{	
		if(IsDisplayedByXpath("//*[@id=\"content\"]/table/tbody/tr[2]/td[1]/form/div/table/tbody/tr[1]/td/b")==false)
		{
			System.out.println("problem in LoginPage verification");	
		}

	}

	public Mocktrading_LoginPage Mocktrading_Username(String usname) throws IOException
	{
		EnterByName(or.getProperty("Username"),usname);

		return this;

	}

	public Mocktrading_LoginPage Mocktrading_Password(String pass) throws IOException
	{
		EnterByName(or.getProperty("Password"),pass);

		return this;
	}


	public MainMenuPage Mocktrading_SubmitBtn() throws IOException
	{
		ClickByXpath(or.getProperty("SubmitBtn"));
		return new MainMenuPage();
	}




}
